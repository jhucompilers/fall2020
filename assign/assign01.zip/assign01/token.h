#ifndef TOKEN_H
#define TOKEN_H

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

enum TokenKind {
  // TODO: add enumeration members

  TOK_IDENTIFIER, // this is just an example
};

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // TOKEN_H
